/********************************************************************************
** Form generated from reading UI file 'room.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ROOM_H
#define UI_ROOM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Room
{
public:
    QListWidget *online_list;
    QPushButton *send_btn;
    QLabel *label;
    QLineEdit *input_le;
    QTextEdit *show_message_te;
    QLabel *label_4;
    QPushButton *refresh_btn;
    QLabel *label_5;
    QPushButton *room_exit_btn;

    void setupUi(QWidget *Room)
    {
        if (Room->objectName().isEmpty())
            Room->setObjectName(QStringLiteral("Room"));
        Room->resize(850, 650);
        Room->setMinimumSize(QSize(750, 540));
        Room->setMaximumSize(QSize(850, 650));
        online_list = new QListWidget(Room);
        online_list->setObjectName(QStringLiteral("online_list"));
        online_list->setGeometry(QRect(640, 60, 171, 501));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(10);
        online_list->setFont(font);
        send_btn = new QPushButton(Room);
        send_btn->setObjectName(QStringLiteral("send_btn"));
        send_btn->setGeometry(QRect(610, 590, 101, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(11);
        send_btn->setFont(font1);
        label = new QLabel(Room);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 20, 72, 15));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font2.setPointSize(9);
        label->setFont(font2);
        input_le = new QLineEdit(Room);
        input_le->setObjectName(QStringLiteral("input_le"));
        input_le->setGeometry(QRect(20, 590, 581, 41));
        show_message_te = new QTextEdit(Room);
        show_message_te->setObjectName(QStringLiteral("show_message_te"));
        show_message_te->setGeometry(QRect(23, 40, 571, 521));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font3.setPointSize(12);
        show_message_te->setFont(font3);
        show_message_te->setReadOnly(true);
        label_4 = new QLabel(Room);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(640, 40, 72, 15));
        QFont font4;
        font4.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font4.setPointSize(8);
        label_4->setFont(font4);
        refresh_btn = new QPushButton(Room);
        refresh_btn->setObjectName(QStringLiteral("refresh_btn"));
        refresh_btn->setGeometry(QRect(760, 40, 51, 21));
        refresh_btn->setFont(font4);
        label_5 = new QLabel(Room);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(0, 0, 850, 650));
        label_5->setMinimumSize(QSize(750, 540));
        label_5->setMaximumSize(QSize(850, 650));
        label_5->setPixmap(QPixmap(QString::fromUtf8(":/image/background.jpg")));
        label_5->setScaledContents(true);
        room_exit_btn = new QPushButton(Room);
        room_exit_btn->setObjectName(QStringLiteral("room_exit_btn"));
        room_exit_btn->setGeometry(QRect(780, 610, 61, 28));
        QFont font5;
        font5.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        room_exit_btn->setFont(font5);
        label_5->raise();
        online_list->raise();
        send_btn->raise();
        label->raise();
        input_le->raise();
        show_message_te->raise();
        label_4->raise();
        refresh_btn->raise();
        room_exit_btn->raise();

        retranslateUi(Room);

        QMetaObject::connectSlotsByName(Room);
    } // setupUi

    void retranslateUi(QWidget *Room)
    {
        Room->setWindowTitle(QApplication::translate("Room", "Form", 0));
        send_btn->setText(QApplication::translate("Room", "\345\217\221\351\200\201", 0));
        label->setText(QApplication::translate("Room", "\350\201\212\345\244\251\350\256\260\345\275\225", 0));
        label_4->setText(QApplication::translate("Room", "\345\234\250\347\272\277\347\224\250\346\210\267", 0));
        refresh_btn->setText(QApplication::translate("Room", "\345\210\267\346\226\260", 0));
        label_5->setText(QString());
        room_exit_btn->setText(QApplication::translate("Room", "\351\200\200\345\207\272", 0));
    } // retranslateUi

};

namespace Ui {
    class Room: public Ui_Room {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ROOM_H
