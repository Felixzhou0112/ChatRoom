/********************************************************************************
** Form generated from reading UI file 'mainwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWIDGET_H
#define UI_MAINWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWidget
{
public:
    QListWidget *room_list;
    QLabel *label;
    QLabel *label_2;
    QPushButton *refresh_btn;
    QPushButton *set_room_btn;
    QLabel *label_3;
    QPushButton *join_room_btn;

    void setupUi(QWidget *MainWidget)
    {
        if (MainWidget->objectName().isEmpty())
            MainWidget->setObjectName(QStringLiteral("MainWidget"));
        MainWidget->resize(450, 465);
        MainWidget->setMinimumSize(QSize(450, 465));
        MainWidget->setMaximumSize(QSize(450, 465));
        room_list = new QListWidget(MainWidget);
        room_list->setObjectName(QStringLiteral("room_list"));
        room_list->setGeometry(QRect(30, 110, 171, 281));
        label = new QLabel(MainWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 10, 371, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font.setPointSize(16);
        label->setFont(font);
        label_2 = new QLabel(MainWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 80, 91, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font1.setPointSize(8);
        label_2->setFont(font1);
        refresh_btn = new QPushButton(MainWidget);
        refresh_btn->setObjectName(QStringLiteral("refresh_btn"));
        refresh_btn->setGeometry(QRect(150, 390, 51, 21));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font2.setPointSize(7);
        refresh_btn->setFont(font2);
        set_room_btn = new QPushButton(MainWidget);
        set_room_btn->setObjectName(QStringLiteral("set_room_btn"));
        set_room_btn->setGeometry(QRect(241, 199, 131, 41));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font3.setPointSize(11);
        set_room_btn->setFont(font3);
        label_3 = new QLabel(MainWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(0, 0, 450, 465));
        label_3->setMinimumSize(QSize(450, 465));
        label_3->setMaximumSize(QSize(450, 465));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/image/background.jpg")));
        label_3->setScaledContents(true);
        join_room_btn = new QPushButton(MainWidget);
        join_room_btn->setObjectName(QStringLiteral("join_room_btn"));
        join_room_btn->setEnabled(false);
        join_room_btn->setGeometry(QRect(241, 257, 131, 41));
        join_room_btn->setFont(font3);
        label_3->raise();
        room_list->raise();
        label->raise();
        label_2->raise();
        refresh_btn->raise();
        set_room_btn->raise();
        join_room_btn->raise();

        retranslateUi(MainWidget);

        QMetaObject::connectSlotsByName(MainWidget);
    } // setupUi

    void retranslateUi(QWidget *MainWidget)
    {
        MainWidget->setWindowTitle(QApplication::translate("MainWidget", "Form", 0));
        label->setText(QApplication::translate("MainWidget", "<html><head/><body><p align=\"center\">Welcome to FreeChat</p></body></html>", 0));
        label_2->setText(QApplication::translate("MainWidget", "\345\275\223\345\211\215\346\210\277\351\227\264\345\210\227\350\241\250", 0));
        refresh_btn->setText(QApplication::translate("MainWidget", "\345\210\267\346\226\260", 0));
        set_room_btn->setText(QApplication::translate("MainWidget", "\345\210\233\345\273\272\346\210\221\347\232\204\346\210\277\351\227\264", 0));
        label_3->setText(QString());
        join_room_btn->setText(QApplication::translate("MainWidget", "\345\212\240\345\205\245\346\255\244\346\210\277\351\227\264", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWidget: public Ui_MainWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWIDGET_H
