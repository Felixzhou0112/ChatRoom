/********************************************************************************
** Form generated from reading UI file 'welcome.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WELCOME_H
#define UI_WELCOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Welcome
{
public:
    QLabel *label;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *user_lab;
    QLineEdit *user_le;
    QHBoxLayout *horizontalLayout_2;
    QLabel *passwd_lab;
    QLineEdit *passwd_le;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QPushButton *regist_btn;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *login_btn;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_2;

    void setupUi(QWidget *Welcome)
    {
        if (Welcome->objectName().isEmpty())
            Welcome->setObjectName(QStringLiteral("Welcome"));
        Welcome->resize(450, 400);
        Welcome->setMinimumSize(QSize(450, 400));
        Welcome->setMaximumSize(QSize(450, 400));
        label = new QLabel(Welcome);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 450, 400));
        label->setMinimumSize(QSize(450, 400));
        label->setMaximumSize(QSize(450, 400));
        label->setPixmap(QPixmap(QString::fromUtf8(":/image/background.jpg")));
        label->setScaledContents(true);
        layoutWidget = new QWidget(Welcome);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 90, 361, 271));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        user_lab = new QLabel(layoutWidget);
        user_lab->setObjectName(QStringLiteral("user_lab"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(user_lab->sizePolicy().hasHeightForWidth());
        user_lab->setSizePolicy(sizePolicy);
        user_lab->setMinimumSize(QSize(40, 40));
        user_lab->setMaximumSize(QSize(40, 40));
        user_lab->setTextFormat(Qt::AutoText);
        user_lab->setPixmap(QPixmap(QString::fromUtf8(":/image/user.png")));
        user_lab->setScaledContents(true);

        horizontalLayout->addWidget(user_lab);

        user_le = new QLineEdit(layoutWidget);
        user_le->setObjectName(QStringLiteral("user_le"));
        user_le->setMinimumSize(QSize(250, 35));
        user_le->setMaximumSize(QSize(250, 35));

        horizontalLayout->addWidget(user_le);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        passwd_lab = new QLabel(layoutWidget);
        passwd_lab->setObjectName(QStringLiteral("passwd_lab"));
        passwd_lab->setMinimumSize(QSize(40, 40));
        passwd_lab->setMaximumSize(QSize(40, 40));
        passwd_lab->setPixmap(QPixmap(QString::fromUtf8(":/image/passwd.png")));
        passwd_lab->setScaledContents(true);

        horizontalLayout_2->addWidget(passwd_lab);

        passwd_le = new QLineEdit(layoutWidget);
        passwd_le->setObjectName(QStringLiteral("passwd_le"));
        passwd_le->setMinimumSize(QSize(250, 35));
        passwd_le->setMaximumSize(QSize(250, 35));
        passwd_le->setEchoMode(QLineEdit::Password);

        horizontalLayout_2->addWidget(passwd_le);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        regist_btn = new QPushButton(layoutWidget);
        regist_btn->setObjectName(QStringLiteral("regist_btn"));
        regist_btn->setAutoFillBackground(false);

        horizontalLayout_3->addWidget(regist_btn);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        login_btn = new QPushButton(layoutWidget);
        login_btn->setObjectName(QStringLiteral("login_btn"));

        horizontalLayout_3->addWidget(login_btn);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_3);

        label_2 = new QLabel(Welcome);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(0, 20, 451, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(20);
        font.setBold(false);
        font.setWeight(50);
        label_2->setFont(font);

        retranslateUi(Welcome);

        QMetaObject::connectSlotsByName(Welcome);
    } // setupUi

    void retranslateUi(QWidget *Welcome)
    {
        Welcome->setWindowTitle(QApplication::translate("Welcome", "Welcome", 0));
        label->setText(QString());
        user_lab->setText(QString());
        passwd_lab->setText(QString());
        regist_btn->setText(QApplication::translate("Welcome", "\346\263\250\345\206\214", 0));
        login_btn->setText(QApplication::translate("Welcome", "\347\231\273\351\231\206", 0));
        label_2->setText(QApplication::translate("Welcome", "<html><head/><body><p align=\"center\">Welcome</p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class Welcome: public Ui_Welcome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WELCOME_H
