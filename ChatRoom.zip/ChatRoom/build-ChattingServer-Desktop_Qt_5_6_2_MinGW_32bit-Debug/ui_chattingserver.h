/********************************************************************************
** Form generated from reading UI file 'chattingserver.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATTINGSERVER_H
#define UI_CHATTINGSERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChattingServer
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QTextEdit *textEdit;

    void setupUi(QWidget *ChattingServer)
    {
        if (ChattingServer->objectName().isEmpty())
            ChattingServer->setObjectName(QStringLiteral("ChattingServer"));
        ChattingServer->resize(400, 300);
        ChattingServer->setMinimumSize(QSize(400, 300));
        ChattingServer->setMaximumSize(QSize(400, 300));
        verticalLayout_2 = new QVBoxLayout(ChattingServer);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(ChattingServer);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221 Light"));
        font.setPointSize(11);
        label->setFont(font);

        verticalLayout->addWidget(label);

        textEdit = new QTextEdit(ChattingServer);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setReadOnly(true);

        verticalLayout->addWidget(textEdit);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(ChattingServer);

        QMetaObject::connectSlotsByName(ChattingServer);
    } // setupUi

    void retranslateUi(QWidget *ChattingServer)
    {
        ChattingServer->setWindowTitle(QApplication::translate("ChattingServer", "ChattingServer", 0));
        label->setText(QApplication::translate("ChattingServer", "<html><head/><body><p align=\"center\">\350\277\236\346\216\245\344\277\241\346\201\257</p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class ChattingServer: public Ui_ChattingServer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATTINGSERVER_H
