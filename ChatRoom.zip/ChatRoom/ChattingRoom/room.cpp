#include "room.h"
#include "ui_room.h"
#include <QCloseEvent>

//��������๹�캯��
Room::Room(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Room)
{
    ui->setupUi(this);
}

//�����������������
Room::~Room()
{
    delete ui;
}

//��������൥������
Room &Room::getInstance()
{
    static Room instance;
    return instance;
}

QString Room::getRoomName()
{
    return m_roomName;
}

//���뷿��ɹ�ʱ��ʾ���з����Ա����
void Room::showRoomMember(PDU *pdu)
{
    if(NULL == pdu)
    {
        return;
    }
    ui->online_list->clear();
    uint size = pdu->messageLength/32;
    char temp[32] = {'\0'};
    for(uint i=0; i<size; i++)
    {
        strncpy(temp, (char*)(pdu->message)+i*32, 32);
        ui->online_list->addItem(temp);
    }
}

//��¼��������
void Room::setRoomName(const char *roomName)
{
    QString self = Welcome::getInstance().m_myName;
    QString title = QString("%1 join %2's room").arg(self).arg(roomName);
    Room::setWindowTitle(title);
    m_roomName = roomName;
}

//ˢ�·������������Ա����
void Room::refreshOnlineList(PDU *pdu)
{
    if(NULL == pdu)
    {
        return;
    }
    ui->online_list->clear();
    uint size = pdu->messageLength/32;
    char temp[32] = {'\0'};
    for(uint i=0; i<size; i++)
    {
        strncpy(temp, (char*)(pdu->message)+i*32, 32);
        ui->online_list->addItem(temp);
    }
}

//��ʾ��Ϣ����
void Room::showMessage(QString name, PDU *pdu)
{
    if(m_roomName == name)
    {
        QString words = (char*)pdu->message;
        QString message = QString("%1(owner):%2").arg(name).arg(words);
        qDebug() << "owner will put on this message" << message;
        ui->show_message_te->append(message);
    }
    else
    {

        QString words = (char*)pdu->message;
        QString message = QString("%1:%2").arg(name).arg(words);
        qDebug() << "member will put on this message" << message;
        ui->show_message_te->append(message);
    }

}

//���ڹر��¼�����
void Room::closeEvent(QCloseEvent *event)
{
    PDU *pdu = makePDU(0);
    if(NULL != pdu)
    {
        pdu->messageType = MESSAGE_TYPE_CLOSE_ROOM_REQUEST;
        strncpy(pdu->name, m_roomName.toStdString().c_str(), 32);
        Welcome::getInstance().getTcpSocket().write((char*)pdu, pdu->PDULength);
        free(pdu);
        pdu = NULL;
    }
    event->ignore();
}

//��������б�����
void Room::clearOnlineList()
{
    ui->online_list->clear();
}

//�����Ϣ����
void Room::clearMessageArea()
{
    ui->show_message_te->clear();
}

////ɾ�������б�ָ���еĺ���
//void Room::clearSpecificOnlineList(const char *name)
//{
//    for(int i=0; i<ui->online_list->count(); i++)
//    {
//        if(0 == strcmp(name, ui->online_list->item(i)->text().toStdString().c_str()))
//        {
//            ui->online_list->takeItem(i);
//        }
//    }
//}

//�³�Ա���뷿��ʱ�����Լ��ķ����Ա�б����ô˺�����ʾ
void Room::updateOnlineList(const char *name)
{
    ui->online_list->addItem(name);
}

//����������߳�Ա�б�ˢ�°�ť���
void Room::on_refresh_btn_clicked()
{
    PDU *pdu = makePDU(0);
    if(NULL != pdu)
    {
        pdu->messageType = MESSAGE_TYPE_REFRESH_ONLINE_LIST_REQUEST;
        strncpy(pdu->name, m_roomName.toStdString().c_str(), 32);
        Welcome::getInstance().getTcpSocket().write((char*)pdu, pdu->PDULength);
        free(pdu);
        pdu = NULL;
    }
}

//���������Ϣ���Ͱ�ť���
void Room::on_send_btn_clicked()
{
    QString message = ui->input_le->text();     //��ȡ��Ϣ����
    if(!message.isEmpty())
    {
        uint length = message.size();
        PDU *pdu = makePDU(length);
        pdu->messageType = MESSAGE_TYPE_SEND_MESSAGE_REQUEST;
        strncpy((char*)(pdu->message), message.toStdString().c_str(), message.size());
        strncpy(pdu->name, m_roomName.toStdString().c_str(), m_roomName.size());
//        qDebug() << "send_pb pressed send--->" << pdu->data;
        Welcome::getInstance().getTcpSocket().write((char*)pdu, pdu->PDULength);
        ui->input_le->clear();
        free(pdu);
        pdu = NULL;
    }
    else
    {
        QMessageBox::warning(this, "send message", "message can not be empty");
    }
}

//�˳����䰴ť���
void Room::on_room_exit_btn_clicked()
{
    PDU *pdu = makePDU(0);
    if(NULL != pdu)
    {
        pdu->messageType = MESSAGE_TYPE_EXIT_ROOM_REQUEST;
        strncpy(pdu->name, m_roomName.toStdString().c_str(), m_roomName.size());
        qDebug() << pdu->name << "be saved and send out";
        Welcome::getInstance().getTcpSocket().write((char*)pdu, pdu->PDULength);
        free(pdu);
        pdu = NULL;
    }
}
