#ifndef WELCOME_H
#define WELCOME_H

#include <QWidget>
#include <QTcpSocket>
#include <QFile>
#include <QByteArray>
#include <QMessageBox>
#include <QHostAddress>

#include "protocol.h"
#include "mainwidget.h"

namespace Ui {
class Welcome;
}

class Welcome : public QWidget
{
    Q_OBJECT

public:
    explicit Welcome(QWidget *parent = 0);
    ~Welcome();

    static Welcome & getInstance();

    void loadConfig();

    QTcpSocket &getTcpSocket();

    char m_myName[32];


    void closeEvent(QCloseEvent *event);

    void handleRegistRespond(PDU *pdu);

    void handleLoginRespond(PDU *pdu);

    void handleSetRoomRespond(PDU *pdu);

    void handleJoinRoomRespond(PDU *pdu);

    void handleRefreshOnlineRespond(PDU *pdu);

    void handleSendMessageRespond(PDU *pdu);

    void handleExitRoomRespond(PDU *pdu);

    void handleCloseRoomRespond();

    void handleCloseWidgetRespond();


signals:

    void newRoomCreated(const char * name);

public slots:
    void showConnection();

    void receiveMessage();

private slots:
    void on_regist_btn_clicked();

    void on_login_btn_clicked();



private:
    Ui::Welcome *ui;
    QString m_IP;
    quint16 m_port;
    QTcpSocket m_tcpSocket;
};

#endif // WELCOME_H
