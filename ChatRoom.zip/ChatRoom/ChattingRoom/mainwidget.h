#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>

#include "welcome.h"
#include "protocol.h"
#include "room.h"


namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

    //��������
    static MainWidget & getInstance();

    //��ʾ�����б�����
    void showRoomList(PDU *pdu);

    //ˢ�·����б�����
    void refreshRoomList(PDU *pdu);

    //��д�ر��¼�����
    void closeEvent(QCloseEvent *event);


    void setTitle(QString title);

private slots:

    void on_join_room_btn_clicked();

    void on_set_room_btn_clicked();

    void on_refresh_btn_clicked();

//    void on_exit_btn_clicked();

private:
    Ui::MainWidget *ui;
};

#endif // MAINWIDGET_H
