#ifndef ROOM_H
#define ROOM_H

#include <QWidget>
#include "protocol.h"
#include "welcome.h"

namespace Ui {
class Room;
}

class Room : public QWidget
{
    Q_OBJECT

public:
    explicit Room(QWidget *parent = 0);
    ~Room();

    static Room &getInstance();

    QString getRoomName();

    void showRoomMember(PDU * pdu);

    void setRoomName(const char *roomName);

    void refreshOnlineList(PDU *pdu);

    void showMessage(QString name, PDU *pdu);

    void closeEvent(QCloseEvent *event);

    void clearOnlineList();

    void clearMessageArea();

    void clearSpecificOnlineList(const char *name);

public slots:
    void updateOnlineList(const char * name);

private slots:
    void on_refresh_btn_clicked();

    void on_send_btn_clicked();



    void on_room_exit_btn_clicked();

private:
    Ui::Room *ui;
    QString m_roomName;
};

#endif // ROOM_H
